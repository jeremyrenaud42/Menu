﻿admin:
function CheckAdminStatus
{
    $adminStatus = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]'Administrator') 
    return $adminStatus
}
internet:
function CheckInternetStatus
{
    while (!(test-connection 8.8.8.8 -Count 1 -quiet)) #Ping Google et recommence jusqu'a ce qu'il y est internet
    {
    [Microsoft.VisualBasic.Interaction]::MsgBox("Veuillez vous connecter à Internet et cliquer sur OK",'OKOnly,SystemModal,Information', "Installation Windows") | Out-Null
    start-sleep 5
    }
}
Sourcepath:
test-path "$env:SystemDrive\_Tech\Applications\Installation\source"
module: 
$modulesFolder = test-path "$env:SystemDrive\_Tech\Applications\Source\modules"
winget:
$wingetVersion = winget -v
    $nb = $wingetVersion.substring(1) 
    $nb -le '1.6'
choco:
$chocoExist = VerifPresenceApp "$env:SystemDrive\ProgramData\chocolatey"
git:
'https://raw.githubusercontent.com/jeremyrenaud42/'
ftp:
'https://ftp.alexchato9.com/public'

