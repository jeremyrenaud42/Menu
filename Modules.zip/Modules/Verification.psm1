﻿# Fonction pour tester l'URL
function Test-Url ($url)
{
    try {
        # Envoyer une requête GET à l'URL
        $response = Invoke-WebRequest -Uri $url -UseBasicParsing

        # Si le statut de la réponse est OK (200), l'URL est accessible
        if ($response.StatusCode -eq 200) {
            Write-Output "$url est accessible."
        } else {
            Write-Output "$url n'est pas accessible. Statut : $($response.StatusCode)"
        }
    } catch {
        # Si une exception est levée, l'URL n'est pas accessible
        Write-Output "$url n'est pas accessible. Erreur : $_"
    }
}

function CheckAdminStatus
{
    $adminStatus = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]'Administrator') 
    return $adminStatus
}
function CheckInternetStatus
{
   $InternetStatus =  test-connection 8.8.8.8 -Count 1 -quiet
   return $InternetStatus
}
function CheckSourcePath
{
    VerifPresenceApp "$env:SystemDrive\_Tech\Applications\Installation\source"
}
function CheckModulesPath
{
    VerifPresenceApp "$env:SystemDrive\_Tech\Applications\Source\modules"
}
function CheckNugetStatus
{
    $nugetStatus = Get-PackageProvider -name Nuget | Select-Object -expand name
    if($nugetStatus)
    {
        write-host "ca marche"
    }
    else
    {
        write-host "ca marche pas"
    }
}
function CheckWingetStatus
{
    $wingetVersion = winget -v
    $nb = $wingetVersion.substring(1)
    if($nb -le '1.8')
    {
        write-host "$nb"
    }
    else
    {
        write-host "ca marche pas"
    }
}
function CheckChocoStatus
{
    VerifPresenceApp "$env:SystemDrive\ProgramData\chocolatey"
}
function CheckGitStatus
{
    $url = 'https://github.com/jeremyrenaud42/Bat'
    Test-Url -url $url
}
function CheckFtpStatus
{
    $url = 'https://ftp.alexchato9.com/public'
    Test-Url -url $url
}
