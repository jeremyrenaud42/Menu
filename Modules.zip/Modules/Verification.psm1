﻿function GetWindowsUpdate
{
    $formControlsMain.lblProgress.Content = "Mises à jour de Windows"
    [System.Windows.Forms.Application]::DoEvents()
    
    $formControlsMain.richTxtBxOutput.AppendText("Vérification des mises à jour Windows disponible")
    [System.Windows.Forms.Application]::DoEvents()
    $updates = Get-WUList -MaxSize 250mb
    $titles = $($updates.title)

        if($updates.Count -eq 0)
        {
            $formControlsMain.richTxtBxOutput.AppendText("Toutes les mises à jour sont deja installées")
            [System.Windows.Forms.Application]::DoEvents()
        }
        else
        {
            $formControlsMain.richTxtBxOutput.AppendText("Mises à jour disponibles:")
            $formControlsMain.richTxtBxOutput.AppendText("$titles")
            [System.Windows.Forms.Application]::DoEvents()

            $totalUpdates = $updates.Count
            $currentUpdate = 0

                foreach($update in $updates)
                { 
                    $currentUpdate++

<#
$progressParams = @{
            Activity = "Installation des mises à jour"
            Status = "En cours..."
            CurrentOperation = "Mise à jour $($currentUpdate) sur $($totalUpdates): $($update.Title)"
            PercentComplete = ($currentUpdate / $totalUpdates) * 100
        }
        Write-Progress @progressParams
#>
                    $formControlsMain.richTxtBxOutput.AppendText("Téléchargement et Installation de $($update.Title)")
                    [System.Windows.Forms.Application]::DoEvents()
                    $kb = $update.KBArticleID
                    Get-WindowsUpdate -KBArticleID $kb -Install -AcceptAll -IgnoreReboot
                    $formControlsMain.richTxtBxOutput.AppendText("$($update.Title) a été installé")
                    [System.Windows.Forms.Application]::DoEvents()
                }
        $formControlsMain.richTxtBxOutput.AppendText("Toutes les mises à jour ont été installées") 
        [System.Windows.Forms.Application]::DoEvents()
        }   
    Addlog "installationlog.txt" "Mises à jour de Windows effectuées"
}
