﻿# Fonction pour tester l'URL
Add-Type -AssemblyName "System.Net.Http"
function Test-Url($url)
{
    $client = New-Object System.Net.Http.HttpClient
    $response = $client.SendAsync((New-Object System.Net.Http.HttpRequestMessage 'Head', $url)).Result
    $client.Dispose()
    return $response.IsSuccessStatusCode
}
function Get-AdminStatus
{
    $adminStatus = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]'Administrator') 
    return $adminStatus
}
function Get-InternetStatus
{
   $InternetStatus =  test-connection 8.8.8.8 -Count 1 -quiet
   return $InternetStatus
}
function Get-InternetStatusLoop
{
    while (!(test-connection 8.8.8.8 -Count 1 -quiet)) #Ping Google et recommence jusqu'a ce qu'il y est internet
    {
    [Microsoft.VisualBasic.Interaction]::MsgBox("Veuillez vous connecter à Internet et cliquer sur OK",'OKOnly,SystemModal,Information', "Installation Windows") | Out-Null
    start-sleep 5
    }
}
function Get-NugetStatus
{
    $nugetStatus = Get-PackageProvider -name Nuget | Select-Object -expand name
    return $nugetStatus
}
function Get-WingetStatus
{
    $wingetVersion = winget -v
    $nb = $wingetVersion.substring(1)
    return $nb
}
function Get-ChocoStatus
{
    $chocoExist = Test-AppPresence "$env:SystemDrive\ProgramData\chocolatey"
    return $chocoExist
}
function Get-GitStatus
{
    $url = 'https://github.com/jeremyrenaud42/Bat'
    $test = Test-Url -url $url
    return $test
}
function Get-FtpStatus
{
    $url = 'https://ftp.alexchato9.com'
    $test = Test-Url -url $url
    return $test
}