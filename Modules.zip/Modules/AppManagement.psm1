function Test-AppPresence($appPath)
{
    return Test-Path $AppPath
}

function New-Folder($folder) 
{
    $folderPath = "$env:SystemDrive\$folder"
    $folderExist = Test-AppPresence $folderPath 
    if($folderExist -eq $false)
    {
        New-Item $folderPath -ItemType 'Directory' -Force | Out-Null
    }
}

function Get-RemoteFile($file,$downloadLink,$path)
{
    $appExist = Test-AppPresence "$path\$file"
    if($appExist -eq $false)
    {
        Invoke-WebRequest $downloadLink -OutFile "$path\$file"
    }
}

function Start-App($exe,$path)
{
    Start-Process "$path\$exe" -verb runas
}

function Invoke-App($exe,$downloadLink,$path)
{
    Get-RemoteFile $exe $downloadLink $path
    Start-App $exe $path
}

function Expand-ZipFile($zipFile,$path)
{
    Expand-Archive $zipFile $path
    Remove-Item $zipFile
}

function Get-RemoteZipFile($appFolder,$downloadLink,$path)
{
    $appExist = Test-AppPresence "$path\$appFolder"
    $zipFile = "$path\$appFolder.zip"
    if($appExist -eq $false)
    {
        Get-RemoteFile "$appFolder.zip" $downloadLink $path
        Expand-ZipFile $zipFile $path
    }
}

function Start-ExpandedApp($appExe,$appFolder,$path)
{
    Start-Process "$path\$appFolder\$appExe" -verb runas
}

function Invoke-RemoteZipFile($appFolder,$downloadLink,$appExe,$path)
{
    Get-RemoteZipFile $appFolder $downloadLink $path
    Start-ExpandedApp $appExe $appFolder $path
} 

function Remove-App($path)
{
    Remove-Item $path -Force | out-null
}

function Install-Choco
{
    $progressPreference = 'SilentlyContinue' #cache la barre de progres
    $chocoExist = Test-AppPresence "$env:SystemDrive\ProgramData\chocolatey"
    if($chocoExist -eq $false)
    {
        Invoke-WebRequest https://chocolatey.org/install.ps1 -UseBasicParsing | Invoke-Expression | Out-Null #install le module choco
        $env:Path += ";$env:SystemDrive\ProgramData\chocolatey" #permet de pouvoir installer les logiciels sans reload powershell
    }
}

function Install-Winget
{
    $progressPreference = 'SilentlyContinue' #cache la barre de progres
    $wingetVersion = winget -v
    $nb = $wingetVersion.substring(1)
    if($nb -le '1.8')
    {  
        $vclibsUWPVersin = (Get-AppxPackage Microsoft.VCLibs.140.00.UWPDesktop).version
        if($vclibsUWPVersin -lt '14.0.30704.0')
        {
             Get-RemoteFile "Microsoft.VCLibs.140.00.UWPDesktop_14.0.30704.0_x64__8wekyb3d8bbwe.Appx" 'https://raw.githubusercontent.com/jeremyrenaud42/Menu/main/Microsoft.VCLibs.140.00.UWPDesktop_14.0.30704.0_x64__8wekyb3d8bbwe.Appx' "$env:SystemDrive\_Tech\Applications\Source"
             Add-AppxPackage -path "$env:SystemDrive\_Tech\Applications\Source\Microsoft.VCLibs.140.00.UWPDesktop_14.0.30704.0_x64__8wekyb3d8bbwe.Appx" -ForceApplicationShutdown
        }
        $VCLibsExist = (Get-AppxPackage Microsoft.VCLibs.140.00).name
        if($null -eq $VCLibsExist)
        {
            Add-AppxPackage https://aka.ms/Microsoft.VCLibs.x64.14.00.Desktop.appx
        }
        $UIXamlExist = (Get-AppxPackage Microsoft.UI.Xaml.2.8).name
        if($null -eq $UIXamlExist )
        {
            Get-RemoteFile "Microsoft.UI.Xaml.2.8.x64.appx" 'https://raw.githubusercontent.com/jeremyrenaud42/Menu/main/Microsoft.UI.Xaml.2.8.x64.appx' "$env:SystemDrive\_Tech\Applications\Source"
            Add-AppxPackage -path "$env:SystemDrive\_Tech\Applications\Source\Microsoft.UI.Xaml.2.8.x64.appx" -ForceApplicationShutdown
        }
        Get-RemoteFile "winget.msixbundle" 'https://aka.ms/getwinget' "$env:SystemDrive\_Tech\Applications\Source"
        Add-AppxPackage -path "$env:SystemDrive\_Tech\Applications\Source\winget.msixbundle" -ForceApplicationShutdown
    }
}

function Install-Nuget
{
    get-packageprovider -Name Nuget -Force #vérifie et install si false
    $nugetModuleExist = Test-AppPresence "C:\Program Files\WindowsPowerShell\Modules\NuGet"
    if($nugetModuleExist -eq $false)
    {
        Install-Module -Name NuGet -Force #pour use avec PowerShell
    }
}

function Add-DesktopShortcut($shortcutPath,$targetPath,$iconLocation)
{
    $shortcutExist = Test-AppPresence $shortcutPath
    if($shortcutExist -eq $false)
    {
    $WshShell = New-Object -comObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut($shortcutPath)
    $Shortcut.TargetPath = $targetPath
    $Shortcut.IconLocation = $iconLocation
    $Shortcut.Save()
    }
}