function Test-AppPresence {
    <#
   .SYNOPSIS
       VÃ©rifie si le dossier de l'application existe
   .DESCRIPTION
       Peut vÃ©rifier n'importe quel dossier ou fichier en retourant seulement vrai ou faux
   .PARAMETER AppFolderPath
       Le chemin du dossier ou du fichier Ã  vÃ©rifier
   .EXAMPLE
       Test-AppPresence AppFolderPath "C:\path\to\file_or_directory"
       Retourne Vrai si le chemin existe, sinon il retourne Faux
   #>
   [CmdletBinding()]
   param (
       [Parameter(Mandatory=$true)]
       [string]$AppFolderPath
   )


   return Test-Path -Path $AppFolderPath
}

function New-Folder 
{
   [CmdletBinding()]
   param (
       [Parameter(Mandatory=$true)]
       [string]$FolderToCreate
   )


   $folderExist = Test-AppPresence -AppFolderPath $FolderToCreate 
   if($folderExist -eq $false)
   {
       New-Item -Path $FolderToCreate -ItemType 'Directory' -Force | Out-Null
   }
}

function Get-RemoteFile
{
   [CmdletBinding()]
   param (
       [Parameter(Mandatory=$true)]
       [string]$File,
       [Parameter(Mandatory=$true)]
       [string]$DownloadLink,
       [Parameter(Mandatory=$true)]
       [string]$FilePath
   )


   $fileExist = Test-AppPresence -AppFolderPath "$FilePath\$File"
   if($fileExist -eq $false)
   {
       New-Folder $FilePath
       Invoke-WebRequest -Uri $DownloadLink -OutFile "$FilePath\$File"
   }
}

function Get-RemoteFileForce
{
   [CmdletBinding()]
   param (
       [Parameter(Mandatory=$true)]
       [string]$File,
       [Parameter(Mandatory=$true)]
       [string]$DownloadLink,
       [Parameter(Mandatory=$true)]
       [string]$FilePath
   )
   $fileExist = Test-AppPresence -AppFolderPath $FilePath
   if($fileExist -eq $true)
   {
       Invoke-WebRequest -Uri $DownloadLink -OutFile "$FilePath\$File"
   }
}
function Start-App
{
    <#
   .NOTES
       Pas obligé d'avoir l'extension
   #>
   [CmdletBinding()]
   param (
       [Parameter(Mandatory=$true)]
       [string]$ExeFile,
       [Parameter(Mandatory=$true)]
       [string]$FilePath
   )


   Start-Process -FilePath "$FilePath\$ExeFile" -verb runas
}

function Invoke-App
{
   [CmdletBinding()]
   param (
       [Parameter(Mandatory=$true)]
       [string]$ExeFile,
       [Parameter(Mandatory=$true)]
       [string]$DownloadLink,
       [Parameter(Mandatory=$true)]
       [string]$FilePath
   )


   Get-RemoteFile $ExeFile $DownloadLink $FilePath
   Start-App $ExeFile $FilePath
}

function Expand-ZipFile
{
   [CmdletBinding()]
   param (
       [Parameter(Mandatory=$true)]
       [string]$ZipFile,
       [Parameter(Mandatory=$true)]
       [string]$Folderpath
   )
   Expand-Archive "$Folderpath\$ZipFile" -DestinationPath $Folderpath
   Remove-Item "$Folderpath\$ZipFile"
}

function Get-RemoteZipFile
{
   [CmdletBinding()]
   param (
       [Parameter(Mandatory=$true)]
       [string]$File,
       [Parameter(Mandatory=$true)]
       [string]$DownloadLink,
       [Parameter(Mandatory=$true)]
       [string]$FilePath
   )
   $fileExist = Test-AppPresence -AppFolderPath $FilePath\$File
   if($fileExist -eq $false)
   {
       Get-RemoteFile -File "$File.zip" -DownloadLink $DownloadLink -FilePath $FilePath
       Expand-ZipFile "$File.zip" $FilePath
   }
}

function Invoke-RemoteZipFile($ZipFile,$DownloadLink,$FilePath)
{
   Get-RemoteZipFile $ZipFile $DownloadLink $FilePath
   Start-App $ZipFile $FilePath\$ZipFile
} 

function Remove-App($path)
{
   Remove-Item $path -Force | out-null
}

function Install-Choco
{
   $progressPreference = 'SilentlyContinue' #cache la barre de progres
   $chocoExist = Test-AppPresence "$env:SystemDrive\ProgramData\chocolatey"
   if($chocoExist -eq $false)
   {
       Invoke-WebRequest https://chocolatey.org/install.ps1 -UseBasicParsing | Invoke-Expression | Out-Null #install le module choco
       $env:Path += ";$env:SystemDrive\ProgramData\chocolatey" #permet de pouvoir installer les logiciels sans reload powershell
   }
}

function Install-Winget
{
   $progressPreference = 'SilentlyContinue' #cache la barre de progres
   $wingetVersion = winget -v
   $nb = $wingetVersion.substring(1)
   if($nb -le '1.8')
   {  
       $vclibsUWPVersin = (Get-AppxPackage Microsoft.VCLibs.140.00.UWPDesktop).version
       if($vclibsUWPVersin -lt '14.0.30704.0')
       {
            Get-RemoteFile "Microsoft.VCLibs.140.00.UWPDesktop_14.0.30704.0_x64__8wekyb3d8bbwe.Appx" 'https://raw.githubusercontent.com/jeremyrenaud42/Menu/main/Microsoft.VCLibs.140.00.UWPDesktop_14.0.30704.0_x64__8wekyb3d8bbwe.Appx' "$env:SystemDrive\_Tech\Applications\Source"
            Add-AppxPackage -path "$env:SystemDrive\_Tech\Applications\Source\Microsoft.VCLibs.140.00.UWPDesktop_14.0.30704.0_x64__8wekyb3d8bbwe.Appx" -ForceApplicationShutdown
       }
       $VCLibsExist = (Get-AppxPackage Microsoft.VCLibs.140.00).name
       if($null -eq $VCLibsExist)
       {
           Add-AppxPackage https://aka.ms/Microsoft.VCLibs.x64.14.00.Desktop.appx
       }
       $UIXamlExist = (Get-AppxPackage Microsoft.UI.Xaml.2.8).name
       if($null -eq $UIXamlExist )
       {
           Get-RemoteFile "Microsoft.UI.Xaml.2.8.x64.appx" 'https://raw.githubusercontent.com/jeremyrenaud42/Menu/main/Microsoft.UI.Xaml.2.8.x64.appx' "$env:SystemDrive\_Tech\Applications\Source"
           Add-AppxPackage -path "$env:SystemDrive\_Tech\Applications\Source\Microsoft.UI.Xaml.2.8.x64.appx" -ForceApplicationShutdown
       }
       Get-RemoteFile "winget.msixbundle" 'https://aka.ms/getwinget' "$env:SystemDrive\_Tech\Applications\Source"
       Add-AppxPackage -path "$env:SystemDrive\_Tech\Applications\Source\winget.msixbundle" -ForceApplicationShutdown
   }
}

function Install-Nuget
{
   get-packageprovider -Name Nuget -Force #vÃ©rifie et install si false
   $nugetModuleExist = Test-AppPresence "C:\Program Files\WindowsPowerShell\Modules\NuGet"
   if($nugetModuleExist -eq $false)
   {
       Install-Module -Name NuGet -Force #pour use avec PowerShell
   }
}

function Add-DesktopShortcut($shortcutPath,$targetPath,$iconLocation)
{
   $shortcutExist = Test-AppPresence $shortcutPath
   if($shortcutExist -eq $false)
   {
   $WshShell = New-Object -comObject WScript.Shell
   $Shortcut = $WshShell.CreateShortcut($shortcutPath)
   $Shortcut.TargetPath = $targetPath
   $Shortcut.IconLocation = $iconLocation
   $Shortcut.Save()
   }
}