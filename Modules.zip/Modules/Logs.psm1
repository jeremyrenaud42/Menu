function Set-LogFileName($scriptName)
{
    $timestamp = (Get-Date).ToString("yyyyMMddHHmmss")
    $filename = "$scriptName" + "$timestamp" + "_log.txt"
    return $filename 
}

function Initialize-LogFile ($FolderPath,$appName)
{
    $logFile = Get-ChildItem -Path $FolderPath -Filter "*log*" -File -Name
    if ($logFile) 
    {
        return $fileName = $logFile.PSChildName
    } 
    else 
    {
       Set-LogFileName $appName
    }
}

function Add-Log ($filename, $message)
{
    $logFilePath = ".\Source\$filename" #chemin du fichier texte
    (Get-Date).ToString() + " - " + $message | Out-file -filepath $logFilePath -append -force
}

function Remove-Log($filename)
{
    $logFilePath = ".\Source\$filename" #chemin du fichier texte 
    Remove-Item $logFilePath -Force | out-null
}

function Copy-Log($filename,$destination)
{
    Copy-Item ".\Source\$filename" -destination $destination -Force | out-null 
}

function Send-FTPLogs ($LocalFile)
{
    Install-Module -Name Posh-SSH -Scope CurrentUser -force #sa prend nuget
    Import-Module Posh-SSH
    
    $SftpServer = "ftp.alexchato9.com"
    $SftpPort = 6666
    $SftpUser = "Albator"
    $SftpPassword = "bombe123" 
    $RemotePath = "/Albator/Logs"
    
    # Create a new SFTP session avec accept key pour no prompt
    $SftpSession = New-SFTPSession -ComputerName $SftpServer -Port $SftpPort -Credential (New-Object PSCredential($SftpUser, (ConvertTo-SecureString $SftpPassword -AsPlainText -Force))) -AcceptKey
    # Upload the file
    Set-SFTPItem -SessionId $SftpSession.SessionId -Path $LocalFile -Destination $RemotePath
    # Close the SFTP session
    Remove-SFTPSession -SessionId $SftpSession.SessionId
}