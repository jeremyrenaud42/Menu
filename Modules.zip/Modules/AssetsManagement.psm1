﻿# Function to determine season based on date
function Get-Season ($date) 
{
    $dateString = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss", [System.Globalization.CultureInfo]::CreateSpecificCulture("fr-FR"))
    $date = [datetime]::ParseExact($dateString, "yyyy-MM-dd HH:mm:ss", $null)
    $month = $date.Month
    $day = $date.Day

    if (($month -eq 1) -or ($month -eq 2) -or ($month -eq 3 -and $day -lt 21)) 
    {
        return "Winter"
    } 
    
    elseif (($month -eq 3 -and $day -ge 21) -or ($month -eq 4) -or ($month -eq 5) -or ($month -eq 6 -and $day -lt 21)) 
    {
        return "Spring"
    } 
    
    elseif (($month -eq 6 -and $day -ge 21) -or ($month -eq 7) -or ($month -eq 8) -or ($month -eq 9 -and $day -lt 23))
    {
        return "Summer"
    } 
    
    elseif (($month -eq 9 -and $day -ge 23) -or ($month -eq 10 -and $day -lt 21) -or ($month -eq 11) -or ($month -eq 12 -and $day -lt 15)) 
    {
        return "Fall"
    }

    elseif ($month -eq 10 -and $day -ge 21) 
    {
        return "Halloween"
    } 

    elseif ($month -eq 12 -and $day -ge 15) 
    {
        return "Christmas"
    }
     
    else 
    {
        return "Default"
    }
}

$Global:seasonFolderName = Get-Season